Please follow [iRedMail upgrade tutorials](https://docs.iredmail.org/iredmail.releases.html) to use SQL/Shell/Python scripts in this directory, do not run any of them blindly.
